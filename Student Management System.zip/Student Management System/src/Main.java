import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static Scanner sc = new Scanner(System.in);
    private static final ArrayList<student> students = new ArrayList<>(); //creating an arraylist of student data type

    public static student idExists(int id){ //to check if the id exists or not
        for(student s:students){
            if(s.getId()==id){
                return s;
            }
        }
        return null;
    }

    public static void addStudent(){ //if the id is unique, new student is added

        System.out.println("Enter ID:");
        int id = sc.nextInt();
        sc.nextLine();
        if(idExists(id)!=null){
            System.out.println("Already student with this id exists.");
            return;
        }
        System.out.println("Enter Name:"); //getting the rest details too if id doesn't exist
        String name = sc.nextLine();
        System.out.println("Enter Age:");
        int age = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter Grade:");
        String grade = sc.nextLine();

        students.add(new student(id, name, age, grade));
        System.out.println("Student added successfully !!!");
    }

    public static void updateDetails(){ //if id exists, details are updated
        int option;

        do{
            System.out.println("\nWhat detail do you want to update? ");
            System.out.println("1. Id.");
            System.out.println("2. Name.");
            System.out.println("3. Age.");
            System.out.println("4. Grade.");
            System.out.println("5. Nothing.");
            option = sc.nextInt();

            if(option == 5) {
                return;
            }
            System.out.println("Enter Id of the student to update");
            int id = sc.nextInt();
            sc.nextLine();

            if(idExists(id)!=null){
                student currentStudent = idExists(id);
                switch(option){
                    case 1:
                        System.out.println("Enter new ID: ");
                        int idu = sc.nextInt();
                        sc.nextLine();
                        if(currentStudent!=null) currentStudent.setId(idu);
                        System.out.println("ID updated successfully ! ");
                        break;

                    case 2:
                        System.out.println("Enter new Name: ");
                        String name = sc.nextLine();
                        if(currentStudent!=null) currentStudent.setName(name);
                        System.out.println("Name updated successfully ! ");
                        break;

                    case 3:
                        System.out.println("Enter new Age: ");
                        int age = sc.nextInt();
                        sc.nextLine();
                        if(currentStudent!=null) currentStudent.setAge(age);
                        System.out.println("Age updated successfully ! ");
                        break;

                    case 4:
                        System.out.println("Enter new Grade: ");
                        String grade = sc.nextLine();
                        if(currentStudent!=null) currentStudent.setGrade(grade);
                        System.out.println("Grade updated successfully ! ");
                        break;

                    default:
                        System.out.println("Enter valid choice.");
                        break;
                }
            }
            else {
                System.out.println("Student with ID "+id+" doesn't exists.");
            }
        }
        while(true);

    }

    public static void removeStudent(){ //if id exists, all the details of that id are removed

        System.out.println("Enter Id of the student to remove.");
        int id = sc.nextInt();
        sc.nextLine();
        if(idExists(id)!=null){
            student currentStudent = idExists(id);
            students.remove(currentStudent);
            System.out.println("Student with Id: "+id+" removed successfully");
        }
        else {
            System.out.println("No student with this Id.");
        }

    }

    public static void viewAStudent(){ //function to view details of a single student
        System.out.println("Enter Id of the student:");
        int id = sc.nextInt();
        sc.nextLine();

        if(idExists(id)!=null){
            student currentStudent = idExists(id);
            System.out.println(currentStudent);
        }
        else {
            System.out.println("Student with this Id doesn't exists.");
        }
    }

    public static void viewAllStudents(){ //function to view details of all the student
        for(student s:students){
            System.out.println(s);
        }
    }

    public static void main(String[] args) {
        int choice;

        do{
            //menu for the user :
            System.out.println("\n---Student Management System---");
            System.out.println("1. Add a Student.");
            System.out.println("2. Update Details of a Student.");
            System.out.println("3. Remove a Student record.");
            System.out.println("4. View a particular Students.");
            System.out.println("5. View all Students.");
            System.out.println("6. Exit");
            System.out.println("\nEnter your choice: ");
            choice = sc.nextInt();

            switch(choice){

                case 1:
                    addStudent(); //to add a new student
                    break;

                case 2:
                    updateDetails(); //to update details in existing one
                    break;

                case 3:
                    removeStudent(); //to remove existing student
                    break;

                case 4:
                    viewAStudent(); //to view a particular student
                    break;

                case 5:
                    viewAllStudents(); //to view all students
                    break;

                case 6:
                    System.out.println("Do you really want to exit? (1-yes/0-no)");
                    int option = sc.nextInt();
                    if(option == 0) choice = 1;
                    break;

                default:
                    System.out.println("Wrong choice!!!\nTry again.");
            }
        }
        while(choice!=6);
    }
}