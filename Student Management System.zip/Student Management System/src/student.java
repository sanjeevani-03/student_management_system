public class student {

    //information about each student contains:
    private int id;
    private String name;
    private int age;
    private String grade;

    //constructor to add the details about student in one line
    public student(int id, String name, int age, String grade){
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    //to get the id
    public int getId() {
        return id;
    }

    //to set/change/update the id
    public void setId(int id){
        this.id = id;
    }

    //to set/change/update the name
    public void setName(String name){
        this.name = name;
    }

    //to set/change/update the age
    public void setAge(int age) {
        this.age = age;
    }

    //to set/change/update the grade
    public void setGrade(String grade) {
        this.grade = grade;
    }

    //to return a meaningful sentence when "student" is called
    @Override
    public String toString() {
        return "\nStudent Details: \nID:"+id+"\nName:"+name+"\nAge:"+age+"\nGrade:"+grade;
    }
}
